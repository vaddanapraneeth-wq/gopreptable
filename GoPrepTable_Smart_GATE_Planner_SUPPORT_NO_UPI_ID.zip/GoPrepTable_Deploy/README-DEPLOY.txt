GoPrepTable Smart GATE Planner

Data organization:
- data/cse/ = one JSON file per CSE subject
- data/da/ = one JSON file per DA subject
- data/cse-compact/ = one JSON file per CSE Compact subject
- Each subject JSON preserves Course/Subject/Module/Topic hierarchy and source IDs/durations.
- manifest.json in each folder controls which subject files are loaded.

To update one subject later, replace its JSON and keep the manifest filename unchanged.
